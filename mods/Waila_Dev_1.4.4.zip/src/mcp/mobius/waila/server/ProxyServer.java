package mcp.mobius.waila.server;

public class ProxyServer {

	public ProxyServer() {}

	public void registerHandlers(){}	
	public void registerMods(){}
	
	public Object getFont(){return null;}
}
